import { useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FileText, Clock, ListChecks, AlertTriangle, Plus, ArrowUpRight } from "lucide-react";

import StatCard from "../components/StatCard";
import StatusBadge from "../components/StatusBadge";
import StatusChart from "../components/StatusChart";
import ActionsChart from "../components/ActionsChart";
import { useChanges } from "../hooks/useChanges";
import { deriveSummaryStatus, RESUMO_STATUS } from "../utils/changes";
import { formatDate } from "../utils/dates";
import "../styles/ui.css";
import "./Dashboard.css";

const pad2 = (n) => String(n).padStart(2, "0");

function Dashboard() {
  const { changes } = useChanges();
  const navigate = useNavigate();

  const resumo = useMemo(() => {
    return {
      total: changes.length,
      abertas: changes.filter((c) => deriveSummaryStatus(c) === RESUMO_STATUS.ABERTA).length,
      concluidas: changes.filter((c) => deriveSummaryStatus(c) === RESUMO_STATUS.CONCLUIDA).length,
      atrasadas: changes.filter((c) => deriveSummaryStatus(c) === RESUMO_STATUS.ATRASADA).length,
    };
  }, [changes]);

  const recentes = useMemo(
    () => [...changes].sort((a, b) => b.data.localeCompare(a.data)).slice(0, 5),
    [changes],
  );

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div>
          <span className="welcome-label">SISTEMA SGI / GESTÃO</span>
          <h1>Visão geral</h1>
          <p>Acompanhe as mudanças e suas respectivas ações.</p>
        </div>

        <button className="new-change-button" onClick={() => navigate("/nova-mudanca")}>
          <Plus size={18} />
          Nova mudança
        </button>
      </header>

      <section className="stats-grid">
        <StatCard
          title="Total de mudanças"
          value={pad2(resumo.total)}
          description="Registros cadastrados"
          icon={FileText}
          color="blue"
        />
        <StatCard
          title="Abertas"
          value={pad2(resumo.abertas)}
          description="Ainda não concluídas"
          icon={Clock}
          color="orange"
        />
        <StatCard
          title="Concluídas"
          value={pad2(resumo.concluidas)}
          description="Eficácia confirmada"
          icon={ListChecks}
          color="green"
        />
        <StatCard
          title="Atrasadas"
          value={pad2(resumo.atrasadas)}
          description="Execução pendente fora do prazo"
          icon={AlertTriangle}
          color="red"
        />
      </section>

      <section className="charts-grid">
        <StatusChart changes={changes} />
        <ActionsChart changes={changes} />
      </section>

      <section className="dashboard-content">
        <div className="recent-changes">
          <div className="section-header">
            <div>
              <h2>Últimas mudanças</h2>
              <p>Acompanhe os registros recentes.</p>
            </div>

            <button className="view-all-button" onClick={() => navigate("/mudancas")}>
              Ver todas <ArrowUpRight size={16} />
            </button>
          </div>

          {recentes.length === 0 ? (
            <div className="empty">
              <h3>Nenhuma mudança cadastrada</h3>
              <p>
                <Link to="/nova-mudanca">Cadastre a primeira mudança</Link>
              </p>
            </div>
          ) : (
            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Identificação</th>
                    <th>Mudança</th>
                    <th>Elaborador</th>
                    <th>Data</th>
                    <th>Status</th>
                  </tr>
                </thead>

                <tbody>
                  {recentes.map((change) => (
                    <tr key={change.id}>
                      <td className="change-id">
                        <Link to={`/mudancas/${change.id}`}>{change.id}</Link>
                      </td>
                      <td>{change.titulo}</td>
                      <td>{change.elaborador}</td>
                      <td>{formatDate(change.data)}</td>
                      <td>
                        <StatusBadge status={deriveSummaryStatus(change)} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="dashboard-side-card">
          <div className="side-card-icon">
            <AlertTriangle size={22} />
          </div>

          <h3>Atenção às ações</h3>

          <p>
            {resumo.atrasadas > 0
              ? `${resumo.atrasadas} mudança(s) atrasada(s) por execução pendente fora do prazo.`
              : "Nenhuma mudança atrasada no momento."}
          </p>

          <button onClick={() => navigate("/acoes")}>
            Acompanhar ações
            <ArrowUpRight size={16} />
          </button>
        </div>
      </section>
    </div>
  );
}

export default Dashboard;
