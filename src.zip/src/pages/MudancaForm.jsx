import { Fragment, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Plus, Save, Trash2 } from "lucide-react";

import { useAuth } from "../hooks/useAuth";
import { useChanges } from "../hooks/useChanges";
import { CHECKLISTS, CHECKLIST_KEYS, itemLabel } from "../data/checklists";
import {
  actionRef,
  blankAction,
  blankChange,
  buildPayload,
  deriveStatus,
  parseRef,
  STATUS,
  simItems,
  simWithoutAction,
  validateActionPlanning,
  validateChangeOpening,
} from "../utils/changes";
import "../styles/ui.css";

const TITULOS_MUDANCA = ["Simulação A", "Simulação B", "Simulação C", "Simulação D"];

function MudancaForm() {
  const { id } = useParams();
  const { changes } = useChanges();
  const existing = id ? changes.find((c) => c.id === id) : null;

  if (id && !existing) {
    return (
      <div className="card empty">
        <h3>Mudança não encontrada</h3>
        <p>
          <Link to="/mudancas">Voltar para a lista</Link>
        </p>
      </div>
    );
  }

  const isPlanning =
    Boolean(existing) &&
    (deriveStatus(existing) === STATUS.PLANEJAMENTO ||
      simWithoutAction(existing).length > 0 ||
      validateActionPlanning(existing).length > 0);

  if (existing && !isPlanning) {
    return (
      <div className="card empty">
        <h3>Esta mudança não está na etapa de planejamento</h3>
        <p>O formulário de edição fica disponível somente durante a etapa de planejamento.</p>
        <p>
          <Link to={`/mudancas/${existing.id}`}>Voltar para a mudança</Link>
        </p>
      </div>
    );
  }

  // key força um estado novo quando troca de "nova" para "editar" (sem useEffect)
  return <FormBody key={id ?? "nova"} existing={existing} isPlanning={isPlanning} />;
}

function toForm(existing) {
  const base = blankChange();
  const copy = structuredClone(existing);
  return {
    ...base,
    ...copy,
    checklists: { ...base.checklists, ...copy.checklists },
    respostas: { ...base.respostas, ...copy.respostas },
    eficacia: { ...base.eficacia, ...copy.eficacia },
    outros: { ...base.outros, ...copy.outros },
  };
}

function FormBody({ existing, isPlanning }) {
  const navigate = useNavigate();
  const { usuarios } = useAuth();
  const { addChange, updateChange } = useChanges();
  const [form, setForm] = useState(() => (existing ? toForm(existing) : blankChange()));
  const [errors, setErrors] = useState([]);

  const set = (field, value) => setForm((f) => ({ ...f, [field]: value }));

  const toggleChecklist = (key) =>
    setForm((f) => ({ ...f, checklists: { ...f.checklists, [key]: !f.checklists[key] } }));

  const setAnswer = (key, n, value) =>
    setForm((f) => ({
      ...f,
      respostas: { ...f.respostas, [key]: { ...f.respostas[key], [n]: value } },
    }));

  const markAll = (key, value) =>
    setForm((f) => ({
      ...f,
      respostas: {
        ...f.respostas,
        [key]: Object.fromEntries(CHECKLISTS[key].items.map((i) => [i.n, value])),
      },
    }));

  const setOutros = (key, value) =>
    setForm((f) => ({ ...f, outros: { ...f.outros, [key]: value } }));

  const addAction = (checklist = null, item = null) =>
    setForm((f) => ({ ...f, acoes: [...f.acoes, blankAction(checklist, item)] }));

  const patchAction = (actionId, patch) =>
    setForm((f) => ({
      ...f,
      acoes: f.acoes.map((a) => (a.id === actionId ? { ...a, ...patch } : a)),
    }));

  const removeAction = (actionId) =>
    setForm((f) => ({ ...f, acoes: f.acoes.filter((a) => a.id !== actionId) }));

  function handleSubmit(e) {
    e.preventDefault();
    const errs = isPlanning ? validateActionPlanning(form) : validateChangeOpening(form);
    setErrors(errs);
    if (errs.length) {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }

    // id e histórico são controlados pelo provider/reducer
    // eslint-disable-next-line no-unused-vars
    const { id: _id, historico: _historico, ...payload } = buildPayload(form);

    if (existing) {
      updateChange(existing.id, payload);
      navigate(`/mudancas/${existing.id}`);
    } else {
      const novoId = addChange(payload);
      navigate(`/mudancas/${novoId}`);
    }
  }

  const sims = simItems(form);
  const semAcao = simWithoutAction(form);

  // opções do vínculo da ação: geral + itens "Sim" (+ vínculo atual, se a resposta mudou depois)
  const refOptions = (acao) => {
    const opts = [{ value: "geral", label: "Geral" }];
    sims.forEach((s) =>
      opts.push({ value: `${s.checklist}:${s.item}`, label: itemLabel(s.checklist, s.item) }),
    );
    const atual = actionRef(acao);
    if (!opts.some((o) => o.value === atual)) {
      opts.push({ value: atual, label: itemLabel(acao.checklist, acao.item) });
    }
    return opts;
  };

  return (
    <form className="page" onSubmit={handleSubmit} noValidate>
      <header className="page-header">
        <div>
          <span className="page-eyebrow">SISTEMA SGI / GESTÃO</span>
          <h1>{isPlanning ? `Planejamento — ${existing.id}` : "Nova mudança"}</h1>
          <p>
            {isPlanning
              ? 'Crie um plano de ação para cada item respondido como "Sim".'
              : "Registre a mudança e responda todos os itens dos checklists aplicáveis."}
          </p>
        </div>
      </header>

      {errors.length > 0 && (
        <div className="form-errors" role="alert">
          <strong>Corrija os pontos abaixo:</strong>
          <ul>
            {errors.map((err) => (
              <li key={err}>{err}</li>
            ))}
          </ul>
        </div>
      )}

      {!isPlanning && (
        <>
      <section className="card">
        <h2>Identificação</h2>
        <p className="card-sub">Dados gerais da mudança.</p>
        <div className="form-grid">
          <div className="field span-2">
            <label htmlFor="titulo">Título da mudança</label>
            <select id="titulo" className="input" value={form.titulo} onChange={(e) => set("titulo", e.target.value)}>
              <option value="">Selecione o título</option>
              {TITULOS_MUDANCA.map((titulo) => (
                <option key={titulo} value={titulo}>
                  {titulo}
                </option>
              ))}
            </select>
          </div>
          <div className="field span-2">
            <label htmlFor="descricao">Descrição</label>
            <textarea
              id="descricao"
              className="input"
              rows={3}
              value={form.descricao}
              onChange={(e) => set("descricao", e.target.value)}
            />
          </div>
          <div className="field">
            <label htmlFor="elaborador">Elaborador</label>
            <input id="elaborador" className="input" value={form.elaborador} onChange={(e) => set("elaborador", e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="aprovador">Aprovador</label>
            <input id="aprovador" className="input" value={form.aprovador} onChange={(e) => set("aprovador", e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="data">Data</label>
            <input id="data" type="date" className="input" value={form.data} onChange={(e) => set("data", e.target.value)} />
          </div>
        </div>
      </section>

      <section className="card">
        <h2>Checklists aplicáveis</h2>
        <p className="card-sub">Selecione quais avaliações se aplicam a esta mudança.</p>
        <div className="toggle-cards">
          {CHECKLIST_KEYS.map((k) => (
            <label key={k} className="toggle-card">
              <input type="checkbox" checked={Boolean(form.checklists[k])} onChange={() => toggleChecklist(k)} />
              {CHECKLISTS[k].short}
            </label>
          ))}
        </div>

        <div className="toggle-cards" style={{ marginTop: 16 }}>
          <label className="toggle-card">
            <input
              type="checkbox"
              checked={form.riscoSignificativo}
              onChange={(e) => set("riscoSignificativo", e.target.checked)}
            />
            Risco significativo (requer especialista)
          </label>
        </div>
        {form.riscoSignificativo && (
          <div className="field" style={{ marginTop: 14 }}>
            <label htmlFor="especialista">Especialista consultado</label>
            <input id="especialista" className="input" value={form.especialista} onChange={(e) => set("especialista", e.target.value)} />
          </div>
        )}
      </section>

      {CHECKLIST_KEYS.filter((k) => form.checklists[k]).map((k) => (
        <section className="card" key={k}>
          <h2>{CHECKLISTS[k].title}</h2>
          <p className="card-sub">Verificar se a mudança…</p>
          <div className="page-actions no-print" style={{ marginBottom: 8 }}>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => markAll(k, "nao")}>
              Marcar tudo como Não
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => markAll(k, "sim")}>
              Marcar tudo como Sim
            </button>
          </div>
          <div className="checklist">
            {CHECKLISTS[k].items.map((item) => (
              <Fragment key={item.n}>
                <div className="check-row">
                  <span className="check-n">{item.n}</span>
                  <span className="check-text">{item.text}</span>
                  <div className="check-options">
                    <label className="pill-radio">
                      <input
                        type="radio"
                        name={`${k}-${item.n}`}
                        checked={form.respostas[k]?.[item.n] === "sim"}
                        onChange={() => setAnswer(k, item.n, "sim")}
                      />
                      <span className="yes">Sim</span>
                    </label>
                    <label className="pill-radio">
                      <input
                        type="radio"
                        name={`${k}-${item.n}`}
                        checked={form.respostas[k]?.[item.n] === "nao"}
                        onChange={() => setAnswer(k, item.n, "nao")}
                      />
                      <span className="no">Não</span>
                    </label>
                  </div>
                </div>

                {item.outros && form.respostas[k]?.[item.n] === "sim" && (
                  <div className="field" style={{ padding: "0 0 12px 46px" }}>
                    <input
                      className="input"
                      placeholder="Descreva o item"
                      aria-label={`Descrição do item ${item.n}`}
                      value={form.outros?.[k] ?? ""}
                      onChange={(e) => setOutros(k, e.target.value)}
                    />
                  </div>
                )}
              </Fragment>
            ))}
          </div>
        </section>
      ))}
        </>
      )}

      {isPlanning && (
      <section className="card">
        <h2>Planos de ação</h2>
        <p className="card-sub">
          Cada resposta "Sim" precisa de exatamente um plano de ação.
        </p>

        {semAcao.length > 0 && (
          <div className="chip-row">
            {semAcao.map((s) => (
              <button
                type="button"
                key={`${s.checklist}:${s.item}`}
                className="chip"
                onClick={() => addAction(s.checklist, s.item)}
                title="Adicionar ação para este item"
              >
                <Plus size={12} /> {itemLabel(s.checklist, s.item)} sem plano
              </button>
            ))}
          </div>
        )}

        {form.acoes.length === 0 && <p className="hint">Nenhum plano cadastrado.</p>}

        {form.acoes.map((a, i) => (
          <div className="action-edit-row" key={a.id}>
            <div className="field">
              <select
                className="input"
                aria-label={`Vínculo do plano ${i + 1}`}
                value={actionRef(a)}
                onChange={(e) => patchAction(a.id, parseRef(e.target.value))}
              >
                {refOptions(a).map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            </div>
            <input
              className="input"
              placeholder="Ação"
              aria-label={`Descrição do plano ${i + 1}`}
              value={a.acao}
              onChange={(e) => patchAction(a.id, { acao: e.target.value })}
            />
            <select
              className="input"
              aria-label={`Responsável do plano ${i + 1}`}
              value={a.responsavelId ?? ""}
              onChange={(e) => {
                const selecionado = usuarios.find(
                  (u) => u.usuario === e.target.value
                );

                patchAction(a.id, {
                  responsavelId: selecionado?.usuario ?? "",
                  responsavel: selecionado?.nome ?? "",
                });
              }}
            >
              <option value="">Selecione o responsável</option>

              {usuarios.filter((u) => u.papel !== "admin").map((u) => (
                <option key={u.usuario} value={u.usuario}>
                  {u.nome} — {u.usuario}
                </option>
              ))}
            </select>
            <input
              type="date"
              className="input"
              aria-label={`Prazo do plano ${i + 1}`}
              value={a.prazo}
              onChange={(e) => patchAction(a.id, { prazo: e.target.value })}
            />
            <button
              type="button"
              className="btn btn-danger btn-icon"
              aria-label={`Remover plano ${i + 1}`}
              onClick={() => removeAction(a.id)}
            >
              <Trash2 size={15} />
            </button>
          </div>
        ))}

        <div style={{ marginTop: 14 }}>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => addAction()}>
            <Plus size={14} /> Adicionar plano
          </button>
        </div>
      </section>
      )}

      <div className="page-actions">
        <button type="submit" className="btn btn-primary">
          <Save size={16} /> {isPlanning ? "Salvar planejamento" : "Registrar mudança"}
        </button>
        <Link to={existing ? `/mudancas/${existing.id}` : "/mudancas"} className="btn btn-ghost">
          Cancelar
        </Link>
      </div>
    </form>
  );
}

export default MudancaForm;
