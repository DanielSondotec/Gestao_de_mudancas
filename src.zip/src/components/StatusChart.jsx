import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { RESUMO_STATUS, deriveSummaryStatus } from "../utils/changes";
import "../styles/ui.css";

// Mesmas cores dos selos de status.
const CORES = {
  [RESUMO_STATUS.ABERTA]: "#2563eb",
  [RESUMO_STATUS.CONCLUIDA]: "#16a34a",
  [RESUMO_STATUS.ATRASADA]: "#dc2626",
};

function StatusChart({ changes }) {
  const data = Object.values(RESUMO_STATUS)
    .map((status) => ({
      name: status,
      value: changes.filter((c) => deriveSummaryStatus(c) === status).length,
    }))
    .filter((d) => d.value > 0);

  return (
    <div className="card">
      <h2>Mudanças por status</h2>
      <p className="card-sub">Distribuição atual dos registros.</p>

      {data.length === 0 ? (
        <div className="empty">Sem dados para exibir.</div>
      ) : (
        <div style={{ width: "100%", height: 260 }}>
          <ResponsiveContainer>
            <PieChart>
              <Pie
                data={data}
                dataKey="value"
                nameKey="name"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
              >
                {data.map((d) => (
                  <Cell key={d.name} fill={CORES[d.name]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}

export default StatusChart;