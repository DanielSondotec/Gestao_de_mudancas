import { useState } from "react";
import { Check } from "lucide-react";
import { useAuth } from "../hooks/useAuth";
import { useChanges } from "../hooks/useChanges";
import { todayISO, formatDate } from "../utils/dates";
import "../styles/ui.css";

function CompleteAction({ changeId, action }) {
  const { user } = useAuth();
  const { proposeResolution } = useChanges();
  const [resolucao, setResolucao] = useState(action.resolucao ?? "");
  const [date, setDate] = useState(action.resolucaoEm ?? todayISO());
  const [formAberto, setFormAberto] = useState(action.statusPlano === "correcao");

  if (action.statusPlano === "aguardando_aprovacao") {
    return (
      <div className="inline-complete">
        <span>Solução enviada em {formatDate(action.resolucaoEm)}; aguardando avaliação.</span>
      </div>
    );
  }

  if (action.statusPlano === "aprovado") {
    return (
      <div className="inline-complete">
        <span>Aprovada em {formatDate(action.avaliacao?.data ?? action.termino)}</span>
      </div>
    );
  }

  const responsavelDesignado = Boolean(user?.usuario && action.responsavelId === user.usuario);

  if (!responsavelDesignado) {
    return <span>{action.termino ? formatDate(action.termino) : "—"}</span>;
  }

  function handleSubmit(event) {
    event.preventDefault();
    const proposta = resolucao.trim();
    if (!proposta || !date) return;

    proposeResolution(changeId, action.id, proposta, date);
  }

  return (
    <>
      {action.avaliacao?.status === "reprovado" && (
        <p className="hint">Correção solicitada: {action.avaliacao.observacao}</p>
      )}
      {!formAberto && (
        <button type="button" className="btn btn-ghost btn-sm no-print" onClick={() => setFormAberto(true)}>
          {action.statusPlano === "correcao" ? "Corrigir solução" : "Propor solução"}
        </button>
      )}
      {formAberto && (
        <form className="inline-complete no-print" onSubmit={handleSubmit}>
          <textarea
            className="input"
            rows={2}
            style={{ width: 260 }}
            value={resolucao}
            onChange={(e) => setResolucao(e.target.value)}
            aria-label="Solução proposta"
            placeholder="Descreva a solução executada"
            required
          />
          <input
            type="date"
            className="input"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            aria-label="Data da proposta"
            required
          />
          <button type="submit" className="btn btn-primary btn-sm" disabled={!resolucao.trim() || !date}>
            <Check size={14} /> Enviar para avaliação
          </button>
        </form>
      )}
    </>
  );
}

export default CompleteAction;
